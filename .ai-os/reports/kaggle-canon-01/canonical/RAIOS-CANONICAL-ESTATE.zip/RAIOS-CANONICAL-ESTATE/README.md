# RAIOS-CANONICAL-ESTATE

Canonical merge of five Kaggle datasets.
