﻿# RAIOS GREENY-LIFE LIVE DEVELOPMENT MISSION

Repository:
C:\Users\Ghanam\Documents\Codex\Greeny-Life-Repair

Branch:
codex-clean

HEAD:
fb130e232246a00b531835f529f25e4edfae2854

## PRIMARY DIRECTIVE

RAIOS is not waiting for V9 to finish before becoming useful.

RAIOS must learn while working on the real Greeny-Life repository.

The Greeny-Life repository is simultaneously:

1. a real production project,
2. a development environment,
3. a capability source,
4. an experience source,
5. a benchmark environment,
6. a learning environment for RAIOS.

## REUSE LAW

Before creating any new capability:

1. Search the Greeny capability bridge.
2. Search the current repository.
3. Search existing RAIOS skills.
4. Search existing RAIOS memory.
5. Search existing tools.

Only after proving a capability gap may RAIOS propose a new implementation.

Preferred order:

REUSE
-> COMPOSE
-> ADAPT
-> EXTEND
-> CREATE

## LEARNING LAW

Real project work must feed RAIOS evolution.

Task
-> Evidence
-> Existing knowledge lookup
-> Capability lookup
-> Execution/reasoning
-> Outcome
-> Experience
-> Validation
-> Reuse
-> Skill candidate
-> Cost reduction

## V9 START

The first V9 architecture program is:

FAST LEARNING PLANE
+
COGNITIVE WAL
+
DISCOVERED / VALIDATED / CANONICAL
+
ASYNC DURABILITY
+
CAPABILITY REUSE ROUTER

## KAGGLE COMPUTE LAW

Kaggle GPU time is scarce.

Available weekly budget recorded for this mission:

9 hours.

GPU must not be consumed by work that can be performed locally.

Local-first:

- repository scans
- parsing
- manifests
- JSON transformations
- static capability analysis
- deduplication preparation
- mission construction
- evidence packaging

Kaggle-first only when justified:

- expensive model inference
- model comparison
- semantic evaluation at scale
- distillation
- training experiments
- GPU-specific benchmarks

## FIRST KAGGLE MISSION

GREENY CAPABILITY ASSIMILATION

Do not begin by generating new architecture.

First understand and assimilate what already exists.

Required outputs:

- Capability Map
- Reuse Map
- Duplication Map
- Gap Map
- RAIOS -> Greeny Routing Map
- Learning Targets
- V9 Integration Priorities
- Evidence Matrix

## ABSOLUTE RULE

Do not duplicate a capability merely because implementing it again is easy.

Existing proven capability is an asset.

RAIOS must become smarter partly by learning how to reuse the intelligence already present in Greeny-Life.
