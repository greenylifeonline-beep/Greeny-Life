﻿# Greeny-Life -> RAIOS Capability Bridge

Repository: C:\Users\Ghanam\Documents\Codex\Greeny-Life-Repair
Branch: codex-clean
HEAD: fb130e232246a00b531835f529f25e4edfae2854

Policy: REUSE > EXTEND > MERGE > CREATE

## Categories

### CANONICAL_GOVERNANCE

- canonical/governance/eos-assets-registry-v1.json
- canonical/governance/eos-deep-asset-discovery-v1.json
- canonical/governance/eos-knowledge-registry-v1.json
- canonical/governance/keep-assets-files-v1.json
- canonical/governance/keep-core-files-v1.json
- canonical/governance/review-required-files-v1.json
- canonical/intelligence/adapters/gl-dos-governance-gate.ts
  Symbols: GLDOSGovernanceGate
- canonical/intelligence/architecture.manifest.json
- canonical/intelligence/asset_classification_report_v2.json
- canonical/intelligence/cleanup_report.json
- canonical/intelligence/comprehensive_report.json
- canonical/intelligence/contracts/execution-contract.json
- canonical/intelligence/eos-business-contract-discovery.json
- canonical/intelligence/eos-domain-activation-blueprint-v1.json
- canonical/intelligence/eos-enterprise-architecture-final.json
- canonical/intelligence/eos-gels-architecture-alignment.json
- canonical/intelligence/eos-gldos-architecture-alignment.json
- canonical/intelligence/eos-roadmap-readiness.json
- canonical/intelligence/foundation-closure-report-final.json
- canonical/intelligence/intelligence/core/report-writer.ts
  Symbols: ensureReports, generateAllReports, generateCleanupPlan, generateDuplicateReport, generateMigrationDecision, saveReport, summarize
- canonical/intelligence/intelligence/engines/audit-engine.ts
  Symbols: checkDuplicates, load, runAuditEngine, validateProduct
- canonical/intelligence/intelligence/engines/data-integrity-engine.ts
  Symbols: buildIdentityMap, compareProvenance, detectDuplicates, getSlug, normalize, normalizeValue, readJSON, runIntegrityEngine
- canonical/intelligence/intelligence/health/health-reporter.ts
  Symbols: checkEngineFiles, generateHealthReport
- canonical/intelligence/intelligence/schemas/product-schema-map.ts
  Symbols: EXPECTED_PRODUCT_COUNT, getNestedValue, MASTER_PRODUCTS, normalizeProduct, PRODUCT_IDENTITY_FIELDS, PRODUCT_SCHEMA_MAP, resolveCategory, resolveId, resolveImage, resolveProductName, resolveStatus
- canonical/intelligence/README.md
- lib/intelligence/canonical-integrity-adapter.ts
  Symbols: canonicalIntegrityReview

### CONTINUITY

- .ai-os/handoffs/20260815-171701-gemini-cli-GL-001.md
- .ai-os/handoffs/20260815-173642-gemini-cli-GL-003.md
- .ai-os/snapshots/20260815-154312.json
- .ai-os/snapshots/20260815-154454.json
- .ai-os/snapshots/20260815-154502.json
- .ai-os/snapshots/20260815-154605.json
- .ai-os/state/AGENTS.json
- .ai-os/state/CURRENT-STATE.json
- .ai-os/state/DECISIONS.md
- .ai-os/state/LOCKS.json
- .ai-os/state/TASKS.json

### EVIDENCE_VALIDATION

- lib/intelligence/greeny-life-verification.ts
  Symbols: runGreenyLifeVerification, trace
- lib/intelligence/official-evidence-gate.ts
  Symbols: assessOfficialExportEvidence, isOfficialEvidenceSourceUrl, isValidIsoDate, REQUIRED_EXPORT_EVIDENCE_GATES
- lib/intelligence/persisted-official-evidence.ts
  Symbols: mapPersistedOfficialEvidence

### LEARNING

- .ai-os/experience/CASE-SCHEMA.json
- .ai-os/experience/pending-validation/CASE-20260815-220056.json
- .ai-os/experience/pending-validation/GL003-LOCAL-20260815-224458.json
- .ai-os/training/README.md
- lib/intelligence/controlled-learning.ts
  Symbols: learningGovernanceAllowsPersistence, learningProposal, validateOutcomeInput
- lib/intelligence/training-factory.ts
  Symbols: buildTrainingCase, validateTrainingCaseInput

### ORCHESTRATION

- .ai-os/ROUTING.md
- canonical/intelligence/runtime/controlled-runtime-orchestrator.ts
  Symbols: ControlledRuntimeOrchestrator
- lib/intelligence/greeny-life-egypt-brain.ts
  Symbols: categoryMatches, greenyLifeEgyptBrainIdentity, greenyLifeEgyptOperationalView
- lib/intelligence/mastermind-agents.ts
  Symbols: assessReadOnlyDecisionSafety, buildMasterMindDecisionPackage, commercialChangeAgent, customerContextAgent, evidenceComplianceAgent, isValidDecisionSafetyPolicy, MASTERMIND_DECISION_POLICY, productMarketAgent, statusFromExport, systemLearningAgent, traceabilityAgent, tradeCorridorAgent
- lib/intelligence/task-orchestration.ts
  Symbols: assessTaskInterestConflict, createTaskContract, detectTaskConflicts, validateTaskInput, validateTaskTransition
- lib/intelligence/three-operating-brains.ts
  Symbols: approvalNotification, escalationReasons, localBrainFor, mastermindAuthority, operatingBrains

### OTHER

- .ai-os/adapters/DEEPSEEK.md
- .ai-os/CORE-CONTRACT.md
- .ai-os/LOCAL-AI-PRIVACY.md
- .ai-os/MASTER-PLAN.md
- .ai-os/MODEL-REGISTRY.json
- .ai-os/PRIVACY-GATE.json
- .ai-os/reports/local-intelligence/DEEPSEEK-LOCAL-BENCHMARK.md
- .ai-os/reports/local-intelligence/GL-003-PREFLIGHT.md
- .ai-os/reports/model-lab/ADAPTIVE-MODEL-LAB.md
- .ai-os/reports/wave-2/BASELINE-MANIFEST.json
- .ai-os/reports/WAVE-2-LAUNCH.md
- .ai-os/WORKTREE-REGISTRY.json
- .cursor/rules/raios-core.mdc
- lib/intelligence/commercial-change-review.ts
  Symbols: commercialChangeReview
- lib/intelligence/commercial-context-fabric.ts
  Symbols: commercialContextSummary, customerContext, samePlace
- lib/intelligence/data-intelligence-fabric.ts
  Symbols: dataFabricCatalog, distributeFabricContext, freshness
- lib/intelligence/evaluation-governance.ts
  Symbols: evaluateCandidate, minimumBenchmarkCases, validateEvaluationInput
- lib/intelligence/export-decision.ts
  Symbols: assessCommercialReadiness, buildExportDecision, buildPersistedExportDecision, commercialRecordMatchesDestination, readJson
- lib/intelligence/gels-label-readiness.ts
  Symbols: evaluateGelsLabel, isEan13, isIsoDate, nonEmpty
- lib/intelligence/legacy-batch-traceability.ts
  Symbols: findLegacyBatch, legacyBatchRegistry, read
- lib/intelligence/operational-data-freshness.ts
  Symbols: assessFreshness, operationalDataStatus
- lib/intelligence/portfolio-and-assets.ts
  Symbols: assetAssimilationRegistry, classifyAsset, egyptianExportPortfolio, readJson
- lib/intelligence/production-readiness.ts
  Symbols: exists, fileIncludes, productionReadinessReport
- lib/intelligence/shipment-tracking-review.ts
  Symbols: shipmentTrackingReview
- lib/intelligence/supplier-quality-review.ts
  Symbols: supplierQualityReview
- lib/intelligence/trade-corridors.ts
  Symbols: assessCorridor, companies, tradeGovernance
- lib/intelligence/workflow-approval.ts
  Symbols: assessWorkflowApproval, findExecutableWorkflowApproval, WORKFLOW_APPROVAL_TTL_MINUTES
- lib/intelligence/workflow-governance.ts
  Symbols: reviewWorkflowTransition
- scripts/data-import-preflight.cjs
  Symbols: evaluateImportData, orderTotalRemediationCandidates
- scripts/legacy-health.cjs
  Symbols: health

### TOOLING

- lib/intelligence/tool-registry.ts
  Symbols: against, and, assetIntelligenceRegistry, createAssetIntelligenceRequest, createE5ConflictReview, createE5MaintenanceCycle, createE5TreatmentApprovalPackage, createE5UnifiedMaintenanceCycle, createE6AssuranceReview, createMaintenancePlan, disposition, purpose, readCapabilities, toolRegistry

