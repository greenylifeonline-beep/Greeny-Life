"""
RAIOS Durability Transaction Engine
===================================

Canonical commit states:

PREPARED
FUTURE_STATE_BUILT
REMOTE_PERSISTED
REMOTE_ACKNOWLEDGED
LOCAL_FINALIZED
COMMITTED

Rule:
No Experience, Skill, Decision or Promotion may become FINAL
before REMOTE_ACKNOWLEDGED.

This module contains the canonical state contract used by future
RAIOS cognitive runtimes.
"""

from enum import Enum


class DurabilityTransactionState(str, Enum):
    PREPARED = "PREPARED"
    FUTURE_STATE_BUILT = "FUTURE_STATE_BUILT"
    REMOTE_PERSISTED = "REMOTE_PERSISTED"
    REMOTE_ACKNOWLEDGED = "REMOTE_ACKNOWLEDGED"
    LOCAL_FINALIZED = "LOCAL_FINALIZED"
    COMMITTED = "COMMITTED"
    ABORTED = "ABORTED"


FINALIZABLE_AFTER = (
    DurabilityTransactionState.REMOTE_ACKNOWLEDGED
)


COGNITIVE_MUTATION_CLASSES = (
    "EXPERIENCE",
    "SKILL",
    "PROMOTION",
    "DECISION",
    "POLICY",
    "TRAINING_CANDIDATE",
)


def can_finalize(state: str) -> bool:
    return state in {
        DurabilityTransactionState.REMOTE_ACKNOWLEDGED.value,
        DurabilityTransactionState.LOCAL_FINALIZED.value,
        DurabilityTransactionState.COMMITTED.value,
    }


def assert_can_finalize(state: str) -> None:
    if not can_finalize(state):
        raise RuntimeError(
            "RAIOS DURABILITY POLICY VIOLATION: "
            "cognitive mutation cannot become FINAL before "
            "REMOTE_ACKNOWLEDGED."
        )


def semantic_commit_state(
    *,
    transaction_id: str,
    mutation_type: str,
    local_hash: str,
    remote_ack: bool,
):
    if mutation_type not in COGNITIVE_MUTATION_CLASSES:
        raise ValueError(
            f"Unknown cognitive mutation type: {mutation_type}"
        )

    return {
        "schema": "raios.semantic-commit-state.v1",
        "transaction_id": transaction_id,
        "mutation_type": mutation_type,
        "local_hash": local_hash,
        "remote_acknowledged": bool(remote_ack),
        "final": bool(remote_ack),
    }
